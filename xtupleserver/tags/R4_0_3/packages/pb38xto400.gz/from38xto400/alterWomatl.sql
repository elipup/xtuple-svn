SELECT createColumn('public', 'womatl', 'womatl_issuewo', 'BOOLEAN', 'FALSE', FALSE);
