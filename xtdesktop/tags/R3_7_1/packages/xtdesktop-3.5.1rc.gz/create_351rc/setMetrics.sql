select setMetric('desktop/welcome','http://welcome.xtuple.org/');
select setMetric('desktop/timer','900000');